module.exports = client => {
  console.log(`Vô hiệu hóa! ${new Date()}`);
};
